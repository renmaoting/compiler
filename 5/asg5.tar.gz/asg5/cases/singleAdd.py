print +++++++10
