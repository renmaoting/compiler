x = 12
x += x
print x
