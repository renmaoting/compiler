print -6+15
