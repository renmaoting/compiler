print 3%14//3
