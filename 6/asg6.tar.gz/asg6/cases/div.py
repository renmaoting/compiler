print 89/2
