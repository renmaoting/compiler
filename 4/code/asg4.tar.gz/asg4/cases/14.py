print 12
