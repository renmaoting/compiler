print -14*14
