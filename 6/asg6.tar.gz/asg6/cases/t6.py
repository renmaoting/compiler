x = 7
def f ( ) :
    x = 99
    x += 1
    print x
print x
f ()
