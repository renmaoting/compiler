x = 10.4
y = 3.5
x -= y
print x
