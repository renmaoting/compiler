print 2+3*8+2*4
