print 2-4%2*0
