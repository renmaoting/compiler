print 86//3
