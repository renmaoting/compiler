print 3-6-7-8
