print 14+15
