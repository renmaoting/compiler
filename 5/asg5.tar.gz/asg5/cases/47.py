abc = 54
xyz = 7
abc /= xyz
print abc
