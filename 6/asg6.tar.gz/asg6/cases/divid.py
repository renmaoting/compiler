print 1+6/2+4/2
