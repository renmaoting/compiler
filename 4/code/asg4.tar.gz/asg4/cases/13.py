print 12**1**12
