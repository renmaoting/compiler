print 14
