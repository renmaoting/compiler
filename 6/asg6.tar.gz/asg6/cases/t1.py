x = 1
def f():
    x = 9
    return x

print f()
print f()
print x
