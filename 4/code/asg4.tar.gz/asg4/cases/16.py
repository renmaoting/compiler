print 9%14
