print 0**13
