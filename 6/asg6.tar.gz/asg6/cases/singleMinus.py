print -----8
