print -10*0
