x = 24.8
y = 23
x %= y
print x
