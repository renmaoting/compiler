print 8%7
