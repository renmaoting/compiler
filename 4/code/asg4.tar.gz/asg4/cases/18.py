print 1*14*5-12
