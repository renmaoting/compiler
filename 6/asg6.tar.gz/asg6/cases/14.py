print -6//11
