print -4%2/2
