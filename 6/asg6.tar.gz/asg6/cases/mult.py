print 5*6*7
