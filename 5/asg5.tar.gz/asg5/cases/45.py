x = 32
y = 3.42
x //= y
print x
