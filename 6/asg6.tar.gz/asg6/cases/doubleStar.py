print 5+4**3
