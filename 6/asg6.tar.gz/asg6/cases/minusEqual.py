x = 12
y = 3
x -= y
print x
