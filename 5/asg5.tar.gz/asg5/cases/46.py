x = 18
x %= 5
print x
