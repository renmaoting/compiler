print -1%2**2
