print -15
