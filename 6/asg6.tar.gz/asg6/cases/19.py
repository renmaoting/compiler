print -1+6//3
